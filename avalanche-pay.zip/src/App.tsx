/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck,
  Clock,
  Coins,
  CheckCircle2,
  Lock,
  Unlock,
  CreditCard,
  Zap,
  ArrowRight,
  RotateCcw,
  Store,
  Smartphone,
  ChevronRight,
  Info,
} from 'lucide-react';
import {
  PaymentItem,
  formatUSDC,
  formatCLP,
  calculateTotalCollected,
  canCollectPayment,
  canRefundPayment,
  collectPayment,
  refundPayment,
  tickEscrowCountdowns,
  generateFakeTxHash,
} from './utils/paymentLogic';

type Tab = 'client' | 'merchant';
type PaymentStep = 'idle' | 'approving' | 'sending' | 'confirmed';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('client');
  const [fastDemoMode, setFastDemoMode] = useState<boolean>(false);

  // Initial payments list as requested
  const [payments, setPayments] = useState<PaymentItem[]>([
    {
      id: '#A-1041',
      concept: 'Café Andes',
      amountUSDC: 12.1,
      amountCLP: 11500,
      status: 'Cobrado',
      createdAt: Date.now() - 3600000 * 2,
      txHash: '0x8f2a…4c91',
      escrowDuration: 60,
      secondsRemaining: 0,
      settlementTimeSeconds: 2.1,
    },
    {
      id: '#A-1040',
      concept: 'Café Andes',
      amountUSDC: 3.25,
      amountCLP: 3100,
      status: 'Reembolsado',
      createdAt: Date.now() - 3600000 * 4,
      txHash: '0x1b4c…9d02',
      escrowDuration: 60,
      secondsRemaining: 0,
      settlementTimeSeconds: 1.9,
    },
  ]);

  // Client order state
  const [orderCounter, setOrderCounter] = useState<number>(1042);
  const currentOrderId = `#A-${orderCounter}`;
  const currentOrderAmountUSDC = 4.82;
  const currentOrderAmountCLP = 4500;

  // Client payment flow state
  const [paymentStep, setPaymentStep] = useState<PaymentStep>('idle');
  const [activeClientPaymentId, setActiveClientPaymentId] = useState<string | null>(null);

  // Step timer refs for clean teardown
  const stepTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Escrow countdown interval (ticks every 1 second)
  useEffect(() => {
    const timer = setInterval(() => {
      setPayments((prev) => tickEscrowCountdowns(prev));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Cleanup payment step timers on unmount
  useEffect(() => {
    return () => {
      if (stepTimerRef.current) clearTimeout(stepTimerRef.current);
    };
  }, []);

  // Handler for starting payment from client app
  const handleStartPayment = () => {
    if (paymentStep !== 'idle') return;

    // Step 1: Aprobando token... (1 s)
    setPaymentStep('approving');

    stepTimerRef.current = setTimeout(() => {
      // Step 2: Enviando pago al contrato... (1 s)
      setPaymentStep('sending');

      stepTimerRef.current = setTimeout(() => {
        // Step 3: Confirmado en Avalanche
        const escrowDuration = fastDemoMode ? 10 : 60;
        const newPayment: PaymentItem = {
          id: currentOrderId,
          concept: 'Café Andes',
          amountUSDC: currentOrderAmountUSDC,
          amountCLP: currentOrderAmountCLP,
          status: 'Retenido',
          createdAt: Date.now(),
          txHash: generateFakeTxHash(),
          escrowDuration,
          secondsRemaining: escrowDuration,
          settlementTimeSeconds: 2.1,
        };

        setPayments((prev) => [newPayment, ...prev]);
        setActiveClientPaymentId(newPayment.id);
        setPaymentStep('confirmed');
      }, 1000);
    }, 1000);
  };

  // Handler to prepare a new order simulation
  const handleNewOrder = () => {
    const nextNum = orderCounter + 1;
    setOrderCounter(nextNum);
    setPaymentStep('idle');
    setActiveClientPaymentId(null);
  };

  // Actions for merchant
  const handleCollect = (id: string) => {
    setPayments((prev) => collectPayment(prev, id));
  };

  const handleRefund = (id: string) => {
    setPayments((prev) => refundPayment(prev, id));
  };

  // Find active client payment
  const activeClientPayment = payments.find((p) => p.id === activeClientPaymentId);
  const totalCollected = calculateTotalCollected(payments);

  return (
    <div className="min-h-screen bg-[#0F1115] text-[#F4F5F7] flex flex-col selection:bg-[#E84142]/30 selection:text-white">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-50 bg-[#0F1115]/95 backdrop-blur-md border-b border-[#262A33] px-4 py-3">
        <div className="max-w-[880px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Brand & Network indicator */}
          <div className="flex items-center gap-3 self-start sm:self-center">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#E84142] animate-pulse" />
              <span className="font-bold tracking-tight text-base text-[#F4F5F7]">
                Avalanche Pay
              </span>
            </div>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#171A21] border border-[#262A33] text-[#9AA1AD] font-mono">
              C-Chain · Sub-segundo
            </span>
          </div>

          {/* Controls: Tabs & Fast Demo Switch */}
          <div className="flex items-center justify-between w-full sm:w-auto gap-3">
            {/* Tab navigation */}
            <nav className="inline-flex p-1 rounded-xl bg-[#171A21] border border-[#262A33]" aria-label="Navegación principal">
              <button
                type="button"
                onClick={() => setActiveTab('client')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all min-h-[38px] ${
                  activeTab === 'client'
                    ? 'bg-[#262A33] text-[#F4F5F7] shadow-sm'
                    : 'text-[#9AA1AD] hover:text-[#F4F5F7]'
                }`}
                aria-pressed={activeTab === 'client'}
              >
                <Smartphone className="w-4 h-4 text-[#E84142]" />
                <span>App del cliente</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('merchant')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all min-h-[38px] ${
                  activeTab === 'merchant'
                    ? 'bg-[#262A33] text-[#F4F5F7] shadow-sm'
                    : 'text-[#9AA1AD] hover:text-[#F4F5F7]'
                }`}
                aria-pressed={activeTab === 'merchant'}
              >
                <Store className="w-4 h-4 text-[#E84142]" />
                <span>Panel del comercio</span>
              </button>
            </nav>

            {/* Fast Demo Mode Toggle */}
            <div className="flex items-center gap-2 pl-2 border-l border-[#262A33]">
              <label
                htmlFor="fast-demo-toggle"
                className="text-xs text-[#9AA1AD] select-none cursor-pointer flex items-center gap-1.5"
                title="Reduce el tiempo de custodia en escrow de 60s a 10s para facilitar pruebas rápidas"
              >
                <Clock className="w-3.5 h-3.5 text-[#9AA1AD]" />
                <span className="hidden md:inline">Modo demo rápida</span>
                <span className="md:hidden">Demo rápida</span>
              </label>
              <button
                id="fast-demo-toggle"
                role="switch"
                aria-checked={fastDemoMode}
                onClick={() => setFastDemoMode(!fastDemoMode)}
                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-[#E84142] focus:ring-offset-1 focus:ring-offset-[#0F1115] ${
                  fastDemoMode ? 'bg-[#E84142]' : 'bg-[#262A33]'
                }`}
                aria-label="Activar modo demo rápida con escrow de 10 segundos"
              >
                <span
                  className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                    fastDemoMode ? 'translate-x-4.5' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 px-4 py-8 max-w-6xl mx-auto w-full flex flex-col justify-center">
        {activeTab === 'client' ? (
          /* ==============================================================
             PESTAÑA 1: APP DEL CLIENTE (diseño tipo teléfono, ancho máx 390px)
             ============================================================== */
          <div className="w-full max-w-[390px] mx-auto">
            {/* Phone Frame container */}
            <div className="bg-[#171A21] border border-[#262A33] rounded-[24px] shadow-2xl p-5 flex flex-col gap-4">
              {/* Header */}
              <div className="flex items-center justify-between border-b border-[#262A33] pb-3">
                <h1 className="text-xl font-bold tracking-tight text-[#F4F5F7]">Pagar</h1>
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#0F1115] border border-[#262A33] text-xs font-mono text-[#9AA1AD]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#E84142]" />
                  <span>0x7a3…f91c</span>
                </div>
              </div>

              {/* Tarjeta del pedido */}
              <div className="bg-[#0F1115] border border-[#262A33] rounded-2xl p-4 text-center">
                <p className="text-xs uppercase tracking-wider font-semibold text-[#9AA1AD]">
                  Café Andes · Orden {currentOrderId}
                </p>
                <div className="mt-2 text-3xl font-extrabold tracking-tight text-[#F4F5F7]">
                  {formatUSDC(currentOrderAmountUSDC)}
                </div>
                <p className="mt-1 text-xs text-[#9AA1AD] font-medium">
                  ≈ {formatCLP(currentOrderAmountCLP)}
                </p>
              </div>

              {/* Tarjeta de detalles con 4 filas */}
              <div className="bg-[#0F1115] border border-[#262A33] rounded-2xl p-4 flex flex-col gap-2.5 text-xs">
                {/* Fila 1: Red */}
                <div className="flex items-center justify-between">
                  <span className="text-[#9AA1AD]">Red</span>
                  <span className="font-semibold text-[#E84142]">Avalanche C-Chain</span>
                </div>

                {/* Fila 2: Liquidación */}
                <div className="flex items-center justify-between">
                  <span className="text-[#9AA1AD]">Liquidación</span>
                  <span className="font-semibold text-[#F4F5F7]">≈ 2 segundos</span>
                </div>

                {/* Fila 3: Comisión de red */}
                <div className="flex items-center justify-between">
                  <span className="text-[#9AA1AD]">Comisión de red</span>
                  <span className="font-semibold text-[#F4F5F7]">Centavos</span>
                </div>

                {/* Fila 4: Protección */}
                <div className="flex items-center justify-between">
                  <span className="text-[#9AA1AD]">Protección</span>
                  <span className="font-semibold text-[#F4F5F7]">
                    Escrow {fastDemoMode ? '10 s' : '60 s'}
                  </span>
                </div>
              </div>

              {/* Texto explicativo */}
              <div className="flex items-start gap-2 bg-[#0F1115]/60 border border-[#262A33] rounded-xl p-3 text-[11px] leading-relaxed text-[#9AA1AD]">
                <Info className="w-4 h-4 text-[#9AA1AD] shrink-0 mt-0.5" />
                <p>
                  Tu dinero queda retenido en un contrato inteligente y pasa al comercio al terminar la retención. Si hay un problema, el comercio puede reembolsarte.
                </p>
              </div>

              {/* Payment Flow / Action Area */}
              {paymentStep === 'idle' && (
                <button
                  type="button"
                  onClick={handleStartPayment}
                  className="w-full min-h-[48px] px-4 py-3 bg-[#C62F30] hover:bg-[#b52a2b] active:bg-[#9f2324] text-white font-bold text-sm rounded-xl transition-colors shadow-lg flex items-center justify-center gap-2 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#E84142] focus:ring-offset-2 focus:ring-offset-[#171A21]"
                >
                  <Coins className="w-4 h-4 text-white" />
                  <span>Pagar con USDC</span>
                </button>
              )}

              {paymentStep === 'approving' && (
                <div className="bg-[#0F1115] border border-[#262A33] rounded-xl p-4 flex flex-col items-center gap-3 text-center">
                  <div className="w-7 h-7 border-2 border-[#E84142] border-t-transparent rounded-full animate-spin" />
                  <div>
                    <p className="font-bold text-sm text-[#F4F5F7]">Aprobando token…</p>
                    <p className="text-[11px] text-[#9AA1AD]">Verificando asignación de USDC en Avalanche</p>
                  </div>
                </div>
              )}

              {paymentStep === 'sending' && (
                <div className="bg-[#0F1115] border border-[#262A33] rounded-xl p-4 flex flex-col items-center gap-3 text-center">
                  <div className="w-7 h-7 border-2 border-[#E84142] border-t-transparent rounded-full animate-spin" />
                  <div>
                    <p className="font-bold text-sm text-[#F4F5F7]">Enviando pago al contrato…</p>
                    <p className="text-[11px] text-[#9AA1AD]">Depositando en el contrato de custodia (Escrow)</p>
                  </div>
                </div>
              )}

              {paymentStep === 'confirmed' && activeClientPayment && (
                <div className="bg-[#0F1115] border border-[#E84142] rounded-xl p-4 flex flex-col gap-3">
                  {/* Step 3 header */}
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-[#E84142] shrink-0" />
                    <span className="font-bold text-sm text-[#F4F5F7]">
                      Confirmado en Avalanche
                    </span>
                  </div>

                  {/* Hash & settlement counter */}
                  <div className="bg-[#171A21] border border-[#262A33] rounded-lg p-2.5 flex flex-col gap-1 text-[11px] font-mono">
                    <div className="flex justify-between items-center text-[#9AA1AD]">
                      <span>Hash de transacción</span>
                      <span className="text-[#F4F5F7]">{activeClientPayment.txHash}</span>
                    </div>
                    <div className="flex justify-between items-center text-[#9AA1AD]">
                      <span>Tiempo de liquidación</span>
                      <span className="text-[#E84142] font-semibold">2,1 s</span>
                    </div>
                  </div>

                  {/* Estado de fondos retenidos con cuenta regresiva */}
                  <div className="bg-[#171A21] border border-[#262A33] rounded-lg p-3 flex flex-col gap-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5 font-semibold text-[#F4F5F7]">
                        {activeClientPayment.status === 'Retenido' ? (
                          <>
                            <Lock className="w-3.5 h-3.5 text-[#E84142]" />
                            <span>Fondos retenidos</span>
                          </>
                        ) : activeClientPayment.status === 'Cobrado' ? (
                          <>
                            <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Fondos cobrados por comercio</span>
                          </>
                        ) : (
                          <>
                            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                            <span className="text-amber-400">Fondos reembolsados</span>
                          </>
                        )}
                      </div>
                      <span className="font-mono text-xs text-[#9AA1AD]">
                        {activeClientPayment.status === 'Retenido'
                          ? `${activeClientPayment.secondsRemaining} s restantes`
                          : activeClientPayment.status}
                      </span>
                    </div>

                    {/* Progress bar for escrow retention */}
                    {activeClientPayment.status === 'Retenido' && (
                      <div className="w-full bg-[#0F1115] h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-[#E84142] h-full transition-all duration-1000"
                          style={{
                            width: `${(activeClientPayment.secondsRemaining / activeClientPayment.escrowDuration) * 100}%`,
                          }}
                        />
                      </div>
                    )}
                  </div>

                  {/* Switch to merchant hint & Reset button */}
                  <div className="flex flex-col gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setActiveTab('merchant')}
                      className="w-full min-h-[44px] px-3 py-2 bg-[#262A33] hover:bg-[#323742] text-[#F4F5F7] text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5"
                    >
                      <span>Ver este pago en Panel del comercio</span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#E84142]" />
                    </button>

                    <button
                      type="button"
                      onClick={handleNewOrder}
                      className="w-full min-h-[40px] px-3 py-1.5 text-xs text-[#9AA1AD] hover:text-[#F4F5F7] transition-colors"
                    >
                      Simular nueva orden
                    </button>
                  </div>
                </div>
              )}

              {/* Bottom security text */}
              <div className="text-center pt-1 border-t border-[#262A33]/70">
                <p className="text-[11px] text-[#9AA1AD]">
                  Firmas con tu wallet. Nadie más mueve tus fondos.
                </p>
              </div>
            </div>
          </div>
        ) : (
          /* ==============================================================
             PESTAÑA 2: PANEL DEL COMERCIO (ancho máximo 880px)
             ============================================================== */
          <div className="w-full max-w-[880px] mx-auto flex flex-col gap-6">
            {/* Header Titles */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-2 border-b border-[#262A33]">
              <div>
                <h1 className="text-2xl font-bold tracking-tight text-[#F4F5F7]">
                  Cobrar hoy vs. cobrar con Avalanche
                </h1>
                <p className="text-sm text-[#9AA1AD] mt-1 font-medium">
                  Panel del comercio · Café Andes
                </p>
              </div>

              {/* Contador resumen: Total cobrado en USDC */}
              <div className="bg-[#171A21] border border-[#262A33] rounded-2xl px-5 py-3 flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-[#0F1115] border border-[#262A33] text-[#E84142]">
                  <Coins className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs uppercase tracking-wider text-[#9AA1AD] font-semibold block">
                    Total cobrado
                  </span>
                  <span className="text-xl font-extrabold text-[#F4F5F7]">
                    {formatUSDC(totalCollected)}
                  </span>
                </div>
              </div>
            </div>

            {/* Dos tarjetas lado a lado (en columna en móvil) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Tarjeta 1: Red de tarjetas tradicional */}
              <div className="bg-[#171A21] border border-[#262A33] rounded-2xl p-5 flex flex-col gap-4">
                <div className="flex items-center gap-2 pb-3 border-b border-[#262A33]">
                  <CreditCard className="w-4 h-4 text-[#9AA1AD]" />
                  <h2 className="font-bold text-sm tracking-wide text-[#9AA1AD]">
                    Red de tarjetas tradicional
                  </h2>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between items-center py-1">
                    <span className="text-[#9AA1AD]">Liquidación</span>
                    <span className="font-medium text-[#F4F5F7]">1 a 3 días</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-t border-[#262A33]/50">
                    <span className="text-[#9AA1AD]">Comisión</span>
                    <span className="font-medium text-[#F4F5F7]">1,5% a 3%</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-t border-[#262A33]/50">
                    <span className="text-[#9AA1AD]">Intermediarios</span>
                    <span className="font-medium text-[#F4F5F7] text-right">
                      Emisor, adquirente y red
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-t border-[#262A33]/50">
                    <span className="text-[#9AA1AD]">Disputas</span>
                    <span className="font-medium text-[#F4F5F7]">Contracargo bancario</span>
                  </div>
                </div>
              </div>

              {/* Tarjeta 2: USDC en Avalanche (borde de color de acento #E84142) */}
              <div className="bg-[#171A21] border-2 border-[#E84142] rounded-2xl p-5 flex flex-col gap-4 relative shadow-lg shadow-[#E84142]/5">
                <div className="flex items-center justify-between pb-3 border-b border-[#262A33]">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-[#E84142]" />
                    <h2 className="font-bold text-sm tracking-wide text-[#F4F5F7]">
                      USDC en Avalanche
                    </h2>
                  </div>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#E84142]/20 text-[#E84142] border border-[#E84142]/40">
                    Recomendado
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between items-center py-1">
                    <span className="text-[#9AA1AD]">Liquidación</span>
                    <span className="font-bold text-[#E84142]">≈ 2 segundos</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-t border-[#262A33]/50">
                    <span className="text-[#9AA1AD]">Comisión</span>
                    <span className="font-bold text-[#F4F5F7]">Centavos de red</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-t border-[#262A33]/50">
                    <span className="text-[#9AA1AD]">Intermediarios</span>
                    <span className="font-bold text-[#F4F5F7]">Contrato inteligente</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-t border-[#262A33]/50">
                    <span className="text-[#9AA1AD]">Disputas</span>
                    <span className="font-bold text-[#F4F5F7]">Escrow con árbitro</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Lista: Pagos recientes */}
            <div className="bg-[#171A21] border border-[#262A33] rounded-2xl p-5 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#E84142]" />
                  <h2 className="font-bold text-base text-[#F4F5F7]">Pagos recientes</h2>
                </div>
                <span className="text-xs text-[#9AA1AD]">
                  {payments.length} transacciones registradas
                </span>
              </div>

              {/* Items List */}
              <div className="divide-y divide-[#262A33]">
                {payments.map((payment) => {
                  const isRetained = payment.status === 'Retenido';
                  const canCollect = canCollectPayment(payment);
                  const canRefund = canRefundPayment(payment);

                  return (
                    <div
                      key={payment.id}
                      className="py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3"
                    >
                      {/* Left: ID, amount, and hash */}
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                            payment.status === 'Cobrado'
                              ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-400'
                              : payment.status === 'Reembolsado'
                              ? 'bg-amber-950/40 border-amber-500/30 text-amber-400'
                              : 'bg-[#0F1115] border-[#E84142]/40 text-[#E84142]'
                          }`}
                        >
                          {payment.status === 'Cobrado' ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : payment.status === 'Reembolsado' ? (
                            <RotateCcw className="w-4 h-4" />
                          ) : (
                            <Lock className="w-4 h-4" />
                          )}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-sm text-[#F4F5F7]">
                              {payment.id}
                            </span>
                            <span className="text-xs text-[#9AA1AD]">·</span>
                            <span className="font-semibold text-sm text-[#F4F5F7]">
                              {formatUSDC(payment.amountUSDC)}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-[#9AA1AD] mt-0.5">
                            <span>Tx: {payment.txHash}</span>
                            <span>·</span>
                            <span>≈ {formatCLP(payment.amountCLP)}</span>
                          </div>
                        </div>
                      </div>

                      {/* Right: Status badge & Actions */}
                      <div className="flex items-center gap-3 self-end md:self-center">
                        {/* Status badge */}
                        <div className="text-right">
                          {isRetained ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#0F1115] border border-[#E84142]/50 text-xs font-mono text-[#E84142]">
                              <span className="w-1.5 h-1.5 rounded-full bg-[#E84142] animate-pulse" />
                              Retenido · {payment.secondsRemaining}s
                            </span>
                          ) : payment.status === 'Cobrado' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-950/40 border border-emerald-500/40 text-xs font-medium text-emerald-400">
                              Cobrado
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-950/40 border border-amber-500/40 text-xs font-medium text-amber-400">
                              Reembolsado
                            </span>
                          )}
                        </div>

                        {/* Action buttons if retained */}
                        {isRetained && (
                          <div className="flex items-center gap-2">
                            {/* Botón Cobrar (habilitado solo cuando la cuenta regresiva llegue a 0) */}
                            <button
                              type="button"
                              onClick={() => handleCollect(payment.id)}
                              disabled={!canCollect}
                              className={`min-h-[44px] px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                                canCollect
                                  ? 'bg-[#E84142] hover:bg-[#d03637] text-white cursor-pointer shadow-md'
                                  : 'bg-[#262A33]/50 text-[#9AA1AD]/50 border border-[#262A33] cursor-not-allowed'
                              }`}
                              title={
                                canCollect
                                  ? 'Liberar fondos retenidos al comercio'
                                  : `Disponible en ${payment.secondsRemaining}s al finalizar la protección de escrow`
                              }
                            >
                              Cobrar
                            </button>

                            {/* Botón Reembolsar (siempre habilitado mientras esté retenido) */}
                            <button
                              type="button"
                              onClick={() => handleRefund(payment.id)}
                              disabled={!canRefund}
                              className="min-h-[44px] px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#262A33] hover:bg-[#323742] text-[#F4F5F7] border border-[#323742] transition-colors cursor-pointer"
                              title="Reembolsar fondos inmediatamente al cliente"
                            >
                              Reembolsar
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#262A33] py-4 px-4 text-center text-xs text-[#9AA1AD]">
        <p>Prototipo de liquidación en tiempo real con USDC y Escrow sobre Avalanche C-Chain</p>
      </footer>
    </div>
  );
}
