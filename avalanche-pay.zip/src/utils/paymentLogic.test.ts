import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatUSDC,
  formatCLP,
  calculateTotalCollected,
  canCollectPayment,
  canRefundPayment,
  collectPayment,
  refundPayment,
  tickEscrowCountdowns,
} from './paymentLogic.ts';
import type { PaymentItem } from './paymentLogic.ts';

const mockPayments: PaymentItem[] = [
  {
    id: '#A-1041',
    concept: 'Café Andes',
    amountUSDC: 12.1,
    amountCLP: 11500,
    status: 'Cobrado',
    createdAt: Date.now() - 3600000,
    txHash: '0x8f2a…4c91',
    escrowDuration: 60,
    secondsRemaining: 0,
    settlementTimeSeconds: 2.1,
  },
  {
    id: '#A-1040',
    concept: 'Café Andes',
    amountUSDC: 3.25,
    amountCLP: 3100,
    status: 'Reembolsado',
    createdAt: Date.now() - 7200000,
    txHash: '0x1b4c…9d02',
    escrowDuration: 60,
    secondsRemaining: 0,
    settlementTimeSeconds: 1.9,
  },
  {
    id: '#A-1042',
    concept: 'Café Andes',
    amountUSDC: 4.82,
    amountCLP: 4500,
    status: 'Retenido',
    createdAt: Date.now(),
    txHash: '0x7e3a…f812',
    escrowDuration: 60,
    secondsRemaining: 30,
    settlementTimeSeconds: 2.1,
  },
];

test('formatUSDC formats with comma for Spanish locale', () => {
  assert.equal(formatUSDC(4.82), '4,82 USDC');
  assert.equal(formatUSDC(12.1), '12,10 USDC');
});

test('calculateTotalCollected only aggregates Cobrado payments', () => {
  const total = calculateTotalCollected(mockPayments);
  assert.equal(total, 12.1);
});

test('escrow collection rules enforce countdown completion', () => {
  const retainedActive = mockPayments[2];
  assert.equal(canCollectPayment(retainedActive), false);
  assert.equal(canRefundPayment(retainedActive), true);

  const retainedReady: PaymentItem = {
    ...retainedActive,
    secondsRemaining: 0,
  };
  assert.equal(canCollectPayment(retainedReady), true);
  assert.equal(canRefundPayment(retainedReady), true);
});

test('collectPayment transitions to Cobrado only when eligible', () => {
  const cannotCollectYet = collectPayment(mockPayments, '#A-1042');
  assert.equal(cannotCollectYet[2].status, 'Retenido');

  const readyList = mockPayments.map((p) =>
    p.id === '#A-1042' ? { ...p, secondsRemaining: 0 } : p
  );
  const collected = collectPayment(readyList, '#A-1042');
  assert.equal(collected[2].status, 'Cobrado');
  assert.equal(calculateTotalCollected(collected), 12.1 + 4.82);
});

test('refundPayment transitions Retenido to Reembolsado', () => {
  const refunded = refundPayment(mockPayments, '#A-1042');
  assert.equal(refunded[2].status, 'Reembolsado');
});

test('tickEscrowCountdowns decreases remaining seconds', () => {
  const ticked = tickEscrowCountdowns(mockPayments);
  assert.equal(ticked[2].secondsRemaining, 29);
});
