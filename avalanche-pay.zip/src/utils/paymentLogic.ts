/**
 * Modelos y lógica pura de pagos para Avalanche Pay
 */

export type PaymentStatus = 'Retenido' | 'Cobrado' | 'Reembolsado';

export interface PaymentItem {
  id: string; // e.g. '#A-1042'
  concept: string; // e.g. 'Café Andes'
  amountUSDC: number;
  amountCLP: number;
  status: PaymentStatus;
  createdAt: number;
  txHash: string;
  escrowDuration: number; // 60 or 10
  secondsRemaining: number;
  settlementTimeSeconds: number;
}

export function formatUSDC(amount: number): string {
  const formatted = amount.toFixed(2).replace('.', ',');
  return `${formatted} USDC`;
}

export function formatCLP(amount: number): string {
  const formatted = Math.round(amount).toLocaleString('es-CL');
  return `$${formatted} CLP`;
}

export function calculateTotalCollected(payments: PaymentItem[]): number {
  return payments
    .filter((p) => p.status === 'Cobrado')
    .reduce((acc, curr) => acc + curr.amountUSDC, 0);
}

export function canCollectPayment(payment: PaymentItem): boolean {
  return payment.status === 'Retenido' && payment.secondsRemaining <= 0;
}

export function canRefundPayment(payment: PaymentItem): boolean {
  return payment.status === 'Retenido';
}

export function collectPayment(payments: PaymentItem[], id: string): PaymentItem[] {
  return payments.map((p) => {
    if (p.id === id && canCollectPayment(p)) {
      return {
        ...p,
        status: 'Cobrado' as PaymentStatus,
        secondsRemaining: 0,
      };
    }
    return p;
  });
}

export function refundPayment(payments: PaymentItem[], id: string): PaymentItem[] {
  return payments.map((p) => {
    if (p.id === id && canRefundPayment(p)) {
      return {
        ...p,
        status: 'Reembolsado' as PaymentStatus,
        secondsRemaining: 0,
      };
    }
    return p;
  });
}

export function tickEscrowCountdowns(payments: PaymentItem[]): PaymentItem[] {
  return payments.map((p) => {
    if (p.status === 'Retenido' && p.secondsRemaining > 0) {
      return {
        ...p,
        secondsRemaining: Math.max(0, p.secondsRemaining - 1),
      };
    }
    return p;
  });
}

export function generateFakeTxHash(): string {
  const chars = '0123456789abcdef';
  let rand = '';
  for (let i = 0; i < 8; i++) {
    rand += chars[Math.floor(Math.random() * chars.length)];
  }
  return `0x${rand.slice(0, 4)}…${rand.slice(4)}`;
}
