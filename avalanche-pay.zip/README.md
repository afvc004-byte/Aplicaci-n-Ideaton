# Avalanche Pay · Prototipo de Pagos Web3

Prototipo interactivo de sistema de pagos sobre la blockchain Avalanche con USDC y contrato inteligente de custodia (Escrow), diseñado como alternativa de liquidación instantánea frente a las redes de tarjetas tradicionales (Visa y Mastercard).

## Características principales

- **App del cliente (móvil 390px):**
  - Interfaz de pago simulada para comercio (*Café Andes · Orden #A-1042*).
  - Flujo de pago en 3 pasos: Aprobación de token, envío al contrato inteligente y confirmación en sub-segundos en Avalanche C-Chain.
  - Período de protección con Escrow y cuenta regresiva en tiempo real.
- **Panel del comercio (880px):**
  - Comparativa directa entre la red de tarjetas tradicional y USDC en Avalanche (liquidación, comisiones, intermediarios y disputas).
  - Contador de total cobrado en USDC.
  - Gestión de pagos recientes con acciones de **Cobrar** (habilitado tras terminar la retención) y **Reembolsar** (disponible durante la custodia).
- **Modo demo rápida:** Interruptor para alternar entre el tiempo de custodia estándar (60s) y demo acelerada (10s).
- **Diseño visual:** Estilo fintech en modo oscuro (`#0F1115`, `#171A21`, `#262A33`), tipografía del sistema, sin emojis y con iconografía SVG.

## Tecnologías

- **React 19**
- **Vite 8**
- **Tailwind CSS v4**
- **Lucide React** (iconografía)
- **TypeScript**

## Cómo ejecutar localmente

1. Clonar el repositorio:
   ```bash
   git clone https://github.com/TU_USUARIO/avalanche-pay.git
   cd avalanche-pay
   ```

2. Instalar dependencias:
   ```bash
   npm install
   ```

3. Iniciar el servidor de desarrollo:
   ```bash
   npm run dev
   ```

4. Abrir en el navegador en [http://localhost:3000](http://localhost:3000).

## Pruebas unitarias

Ejecuta las pruebas de lógica de pagos con el test runner nativo de Node:
```bash
node --test src/utils/paymentLogic.test.ts
```
